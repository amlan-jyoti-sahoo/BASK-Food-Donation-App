import 'package:bask_app/model/District.dart';

class User {
  String uid;
  String name;
  String roleId;
  String? ngoId;
  String phoneNumber;
  String districtId;
  String area;
  String addressDetails;
  String email;
  District? district;

  User(
      {required this.uid,
      required this.name,
      required this.roleId,
      this.ngoId,
      required this.phoneNumber,
      required this.districtId,
      required this.area,
      required this.addressDetails,
      required this.email,
      this.district});

  static User fromJson(json) {
    return User(
      uid: json['uid'],
      name: json['name'],
      roleId: json['roleId'],
      ngoId: json['ngoId'],
      phoneNumber: json['phoneNumber'],
      districtId: json['districtId'],
      area: json['area'],
      addressDetails: json['addressDetails'],
      email: json['email'],
      district: District.fromJson(json['district']),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['uid'] = this.uid;
    data['name'] = this.name;
    data['roleId'] = this.roleId;
    data['ngoId'] = this.ngoId;
    data['phoneNumber'] = this.phoneNumber;
    data['districtId'] = this.districtId;
    data['area'] = this.area;
    data['addressDetails'] = this.addressDetails;
    data['email'] = this.email;
    return data;
  }
}
