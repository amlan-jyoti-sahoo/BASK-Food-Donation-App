import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:bask_app/model/District.dart';

class DistrictApi {
  static Future<List<District>> getAllDistrict() async {
    var uri = Uri.parse('http://baskapi.somee.com/api/districts');
    final response = await http.get(uri);
    final body = json.decode(response.body);

    return body.map<District>(District.fromJson).toList();
  }
}
