import 'dart:convert';
import 'package:bask_app/model/user.dart';
import 'package:http/http.dart' as http;

class UserApi {
  static Future<http.Response> createUser(User user) {
    return http.post(
      Uri.parse('http://baskapi.somee.com/api/users'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(user.toJson()),
    );
  }
}
